#!/usr/bin/env ruby

class ZippedRuby1
  def self.returnTrue
    true
  end
end
