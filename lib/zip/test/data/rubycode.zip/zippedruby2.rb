#!/usr/bin/env ruby

class ZippedRuby2
  def self.returnFalse
    false
  end
end
