#!/usr/bin/env ruby

class ZippedRuby3
  def self.multiplyValues(aValue, anotherValue)
    aValue * anotherValue
  end
end
