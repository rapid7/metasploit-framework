March 23, 2002
Mark Slagell  (slagell@ruby-lang.org)
Iowa State University

======================================================================
WHAT IT IS
======================================================================
This is the Ruby Users' Guide, an introductory tutorial for new users
of the ruby language.  It is provided in HTML form only.  Point a
browser to the file "index.html" to begin.

======================================================================
WHERE TO GET IT
======================================================================
The current version of this document can be viewed at:
      http://www.ruby-lang.org/~slagell/ruby/

======================================================================
CREDITS
======================================================================
Yukihiro Matsumoto (matz@netlab.co.jp), the creator of ruby, wrote the
original guide from which this is derived.

The first translation from Japanese to English was done by
GOTO Kentaro (gotoken@notwork.org) and Julian Fondren.

Further translation and editing was done by Mark Slagell
(slagell@ruby-lang.org).
