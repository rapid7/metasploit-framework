This audit script requires two pre-requisites:

1. A working Ruby installation for Windows, with ruby.exe in the PATH and the win32/registry gem

 Use the link below to download and install Ruby 1.9.1 for Windows:

	http://rubyforge.org/frs/download.php/72075/rubyinstaller-1.9.1-p430.exe



2. A copy of the procmon.exe binary. This binary is part of the SysInternals kit

	http://technet.microsoft.com/en-us/sysinternals/bb896645.aspx

	The procmon.exe must placed into this directory before running audit.bat

Once these have been installed, open the "Ruby Command Line" link from the start menu
 Change into the AuditKit directroy from this shell
 This shell will be the one used to run audit.bat


This script requires babysitting the tested system. You will need to close about 50 windows
during each pass of the audit and you may need to do this for thousands of Windows.

Once the audit.bat script completes, switch to the ProcMon.exe window and save a CSV log
of the filtered events.

Make sure the "Events displayed using current filter" box is checked
Make sure the "Include profiling events" box is unchecked
Make sure you choose "Comma-Separated Values" as the format
Save this result into DLLTest\results.csv

Next, run the exploit generator:

ruby DLLTest\generate.rb

This will create a directory under DLLTest\exploits\ containing a number of
DLLs as well as files called exploit.<ext>. Simply click each of the exploit.<ext>
files and look for the Calculator. Make sure no instance of the application
is running in the background before clicking the file type, as this can prevent
the DLL from the loading.

The automatic generator works most of the time, but there are cases where manual
exploitation is needed. Look at the results in ProcMon to determine what changes
need to be made to exploit a particular application.

