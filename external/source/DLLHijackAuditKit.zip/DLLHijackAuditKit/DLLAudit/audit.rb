#!ruby

# DLL Load Hijacking audit script - <hdm[at]metasploit.com>

require 'fileutils'
require 'win32/registry'

def print_status(msg)
	$stdout.puts "[*] #{msg}"
end

base = File.expand_path(File.dirname(__FILE__))
regk = Win32::Registry::HKEY_LOCAL_MACHINE.open("Software\\Classes")
exts = regk.keys.reject{|x| x !~ /^\./ }

total = exts.length
cnt   = 0

Dir.chdir(base)

print_status("Identified #{total} registered file extensions")
print_status("")
print_status("This script will cause hundreds of popups to appear. It will stop every 50 file extensions")
print_stauts("in order to give you a chance to close these windows and prepare for the next set. You will")
print_stauts("need to hit enter after every 50 extensions to continue the audit.")
print_status("")
exts.each do |e|
	cnt += 1

	# Skip known bad extensions
	ignored = %W{
		pml pmc
		exe pif cmd bat wsh js wse jse com
		rb py
	}

	b = e.sub(".", '').downcase

	next if ignored.include?(b)

	FileUtils.mkdir_p("ext/#{b}/")
	File.open("ext/#{b}/awesome.#{b}", "w") do |fd|
		fd.write("HOWDY")
	end
	Dir.chdir("ext/#{b}/")
	print_status("Testing extension #{b} #{cnt}/#{total}...")
	system("cmd.exe /c start awesome.#{b}")
	Dir.chdir(base)

	if cnt % 50 == 0
		print_status("Close any open windows and press enter to continue...")
		$stdin.readline
	end
end

print_status("Audit completed")