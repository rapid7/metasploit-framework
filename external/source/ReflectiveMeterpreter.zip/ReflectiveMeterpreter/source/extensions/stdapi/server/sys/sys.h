#ifndef _METERPRETER_SOURCE_EXTENSION_STDAPI_STDAPI_SERVER_SYS_SYS_H
#define _METERPRETER_SOURCE_EXTENSION_STDAPI_STDAPI_SERVER_SYS_SYS_H

#include "config/config.h"
#include "process/process.h"
#include "registry/registry.h"
#include "eventlog/eventlog.h"
#include "power/power.h"

#endif
