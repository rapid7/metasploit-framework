#ifndef _METERPRETER_SERVER_REMOTE_DISPATCHER_H
#define _METERPRETER_SERVER_REMOTE_DISPATCHER_H

VOID register_dispatch_routines();
VOID deregister_dispatch_routines();

#endif
