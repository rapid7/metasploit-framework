This is an empty Reflective Dll project* for building you own Dll's for use with testing Reflective Dll Injection.

The ReflectiveLoader is located in the file ./source/ReflectiveLoader.c

You implement your functionality in the Init function which is located in the file ./source/ReflectiveDll.c

* Download Microsoft Visual C++ 2008 Express Edition here: http://www.microsoft.com/express/vc/