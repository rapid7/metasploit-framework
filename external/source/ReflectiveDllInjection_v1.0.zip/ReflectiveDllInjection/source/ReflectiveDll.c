//===============================================================================================//
// This is a stub for the actuall functionality of the DLL. Your code will start in Init()
//===============================================================================================//
#include "ReflectiveLoader.h"

// You can use this value as a pseudo hinstDLL value (defined and set via ReflectiveLoader.c)
extern HINSTANCE hAppInstance;
//===============================================================================================//
DLLEXPORT int Init( SOCKET socket )
{

	// ...add in your functionality here...

	MessageBoxA( NULL, "Hello from Init!", "Reflective Dll", MB_OK );

	return 0;
}
//===============================================================================================//
